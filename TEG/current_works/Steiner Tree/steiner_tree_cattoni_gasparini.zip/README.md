# Como usar

## Preparando o ambiente:

Recomenda-se uso de um sistema Linux. Outra plataforma demanda outros procedimentos

1. Para instalar o Graphviz utilize os seguintes comandos
    1. `sudo apt-get install graphviz`
    2. `pip3 install graphviz`
        
2. Para executar o simulador utilize os seguintes comandos (na pasta raiz do código)
    1. `python3 steiner.py`
