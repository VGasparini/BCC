dark_gray  = 0.1, 0.1, 0.1
light_gray = 0.5, 0.5, 0.5
white      = 0.8, 0.8, 0.8
black      = 0.1, 0.1, 0.1
silver      = 0.7, 0.7, 0.7

red        = 0.8, 0.0, 0.0
green      = 0.0, 0.8, 0.0
blue       = 0.0, 0.0, 0.8

# Cor de ambiente
blue_sky   = 0.08, 0.4, 0.9, 1.0
grass      = 0.1, 0.6, 0.08