#include <math.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
  // entrada das requisicoes em ordem FIFO
  int req[] = {59, 53, 2, 474, 603, 700, 1368, 1446, 1690, 1875};
  // 178,243,480,481,607,774,1166,1634,1661,1874
  int requisicaoAnterior = 212;
  int requisicaoAtual = 210;

  // dados do disco
  float tempoDesloc = 0.5;
  int velocidadeRotacao = 6000;
  float tempoUmaVolta = velocidadeRotacao / 60;
  int tamanhoSetor = 512;
  int qtdSetoresPorTrilha = 128;
  int bytesPorTrilha = tamanhoSetor * qtdSetoresPorTrilha;
  int setoresLidosPorRequisicao = 8192 / tamanhoSetor;

  float tempoLeitura = (1 / (2 * tempoUmaVolta) + ((setoresLidosPorRequisicao * tamanhoSetor) /
                                                   (tempoUmaVolta * bytesPorTrilha)));
  // printf("Tempo para ler uma requisição: %fms\n", tempoLeitura);

  // FSFS
  int distanciaFSFS = abs(requisicaoAtual - req[0]);

  for(int i = 0; i < (sizeof(req) / sizeof(req[0])) - 1; i++) {
    distanciaFSFS += abs(req[i] - req[i + 1]);
  }
  float tempoFSFS = distanciaFSFS * tempoDesloc + (tempoLeitura * (sizeof(req) / sizeof(req[0])));

  printf("Distancia percorrida: %i\n", distanciaFSFS);
  printf("Tempo: %.2fms\n", tempoFSFS);

  return 0;
}