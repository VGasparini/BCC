#include <stdio.h>
#include <stdlib.h>

typedef struct node{
	int bloco_inicial;
	int n_blocos;
	char modo; 
	struct node *prox; 
} requisicoes;

requisicoes *head_req = NULL;
requisicoes *current_req = NULL;

//cria lista
requisicoes * create_list(int inicial, int num_blocos, char modo){
	requisicoes * p = (requisicoes*)malloc(sizeof(requisicoes));
	p->bloco_inicial = inicial;
	p->n_blocos = num_blocos;
	p->modo = modo;
	p->prox = NULL; // o próximo é NULL
	head_req = current_req = p;
	return p;
}

// função que adiciona um elemento na fila (deixa a fila ordenada)
requisicoes* add_list(int inicial, int num_blocos, char modo){
	
	if(head_req == NULL){		
		return create_list(inicial, num_blocos, modo);
	}
	requisicoes * p = (requisicoes*)malloc(sizeof(requisicoes));
	p->bloco_inicial = inicial;
	p->n_blocos = num_blocos;
	p->modo = modo;

	requisicoes * ptr= head_req;
	requisicoes * aux= ptr->prox;
	
	//add na cabeça da lista
	if(ptr->bloco_inicial > inicial){
		p->prox = head_req; 
		head_req = p;
		return p;
	}

	else{
		while(aux != NULL){
			if(aux->bloco_inicial < inicial){
				ptr = aux;
				aux = aux->prox;
			}
			else{
				ptr->prox = p;
				p->prox = aux;
				return p;
			}
		}
	}

	if(aux == NULL){
		p->prox = NULL; 
		current_req->prox = p;
		current_req = p;

	}
	return p;
}

//verifica se a lista está vazia
int lista_vazia(){
	// se cabeca for NULL, então a lista está vazia
	if(head_req == NULL)
		return 1;
	return 0;
}

// função que retorna o tamanho da lista
int tamanho_lista(){
	if(lista_vazia())
		return 0;
	requisicoes *aux = head_req;
	int tam = 0;
	while(aux != NULL){
		tam++;
		aux = aux->prox;
	}
	return tam;
}

//remove cabeça da lista 
void remove_head_req(){
	requisicoes *aux = head_req;
	head_req = head_req->prox;
	free(aux);
}

//faz a busca de um elemento
requisicoes * buscar_elemento(int bloco_inicial_novo, int numero_blocos_novo, char modo, requisicoes **ant){
	// se a lista estiver vazia, então não possui elementos
	if(lista_vazia() == 1)
		return NULL;

	// variável "p" para percorrer a lista
	requisicoes *p = head_req;
	// variável "aux_ant" para guardar o anterior
	requisicoes *aux_ant = NULL;
	// flag "achou" que indica se achou o elemento
	int achou = 0;

	// percorre a lista
	while(p != NULL){
		// se achou, então retorna 1
		if(p->bloco_inicial == bloco_inicial_novo && p->n_blocos == numero_blocos_novo && p->modo == modo){
			achou = 1;
			break;
		}
		// atualiza o "aux_ant"
		aux_ant = p;
		// aponta para o próximo
		p = p->prox;
	}
	// verifica se achou
	if(achou == 1){
		// se "ant" for diferente de NULL
		if(ant)
			*ant = aux_ant; // guarda "aux_ant"
		return p;
	}
	// se chegou aqui, então não achou
	return NULL;
}
//remove depois de uma junção
void remover(int bloco_inicial_novo, int numero_blocos_novo, char modo){
	requisicoes *ant = NULL;

	requisicoes * elem = buscar_elemento(bloco_inicial_novo, numero_blocos_novo, modo, &ant);

	if(elem == NULL)
		return ;

	// se o anterior for diferente de NULL, então
	// faz o próximo do anterior apontar para o próximo
	// do elemento que será removido
	if(ant != NULL)
		ant->prox = elem->prox;

	// se o elemento a ser removido é igual ao corrente, ou seja,
	// é o último elemento, então faz o corrente apontar para o anterior
	if(elem == current_req)
		current_req = ant;

	// se o elemento a ser removido é igual a cabeca, ou seja,
	// é o primeiro elemento, então faz a cabeca apontar para o próximo
	// do elemento a ser removido
	if(elem == head_req)
		head_req = elem->prox;

	// por último, dá um free no elemento a ser removido "elem" e coloca para NULL
	free(elem);
	elem = NULL;
}

void fundir_escrita(requisicoes *p, int bloco_inicial_novo, int numero_blocos_novo, char modo){
	if(bloco_inicial_novo + numero_blocos_novo == p->bloco_inicial){
		p->bloco_inicial = bloco_inicial_novo;
		p->n_blocos = p->n_blocos + numero_blocos_novo;
	}
	else
		p->n_blocos = p->n_blocos + numero_blocos_novo;
}
 int passou = 0;

void fundir_leitura(requisicoes *p, int bloco_inicial_novo, int numero_blocos_novo, char modo){
	int p_final = p->bloco_inicial + p->n_blocos;
	int novo_final = bloco_inicial_novo + numero_blocos_novo;
	
	//novo antecede o antigo
	if(novo_final == p->bloco_inicial){
		p->bloco_inicial = bloco_inicial_novo;
		p->n_blocos = p->n_blocos + numero_blocos_novo;
	}
	//novo sucede o antigo
	else if(p_final == bloco_inicial_novo){
		p->n_blocos = p->n_blocos + numero_blocos_novo;
	}
	//novo comeca antes e termina no meio do antigo
	else if(bloco_inicial_novo < p->bloco_inicial && novo_final < p_final){
		p->bloco_inicial = bloco_inicial_novo;
		p->n_blocos = p_final - bloco_inicial_novo;
	}
	//novo abrange todo o antigo
	else if(bloco_inicial_novo <= p->bloco_inicial && novo_final >= p_final){
		passou++;
		p->bloco_inicial = bloco_inicial_novo;
		p->n_blocos = numero_blocos_novo;
	}
	//novo começa no meio do antigo e o sucede
	else if(bloco_inicial_novo > p->bloco_inicial && novo_final > p_final){
		p->n_blocos = novo_final - p->bloco_inicial + 1;
	}
}

//retorna um ponteiro para o elemento da lista quando é possivel fundir
requisicoes * busca_adjacente(int bloco_inicial_novo, int numero_blocos_novo, char modo){
	requisicoes *p = head_req;
	while (p != NULL){

		int bloco_final_existente = p->bloco_inicial + p->n_blocos-1;
		int bloco_final_novo = bloco_inicial_novo + numero_blocos_novo-1;

		if(p->modo == modo && modo =='r'){
			if((bloco_inicial_novo < p->bloco_inicial && bloco_final_novo >= p->bloco_inicial-1) || 
				(bloco_inicial_novo >= p->bloco_inicial && bloco_inicial_novo <= bloco_final_existente+1) ){
					if(p->n_blocos + numero_blocos_novo < 64){
						fundir_leitura(p, bloco_inicial_novo, numero_blocos_novo, modo);	
						return p;
					}
					return NULL;
			}
		}
		
		if(p->modo == modo && modo =='w'){
			if(bloco_final_novo == p->bloco_inicial-1 || bloco_inicial_novo-1 == bloco_final_existente){
				if(p->n_blocos + numero_blocos_novo < 64){	
					fundir_escrita(p, bloco_inicial_novo, numero_blocos_novo, modo);
					return p;
				}
				return NULL;
			}

		}
		p = p->prox;
	}

	//se nao encontrou, retorna nulo
	return NULL;
}

void manipulador_requisicoes(int bloco_inicial, int numero_blocos, char modo){
	requisicoes *r = busca_adjacente(bloco_inicial, numero_blocos, modo);
	
	if(r == NULL) //se o ponteiro é nulo, adiciona a nova requisição na fila de despacho
		add_list(bloco_inicial, numero_blocos, modo);	
	else{
		if(r->modo == 'w'){	
			requisicoes *s =busca_adjacente(r->bloco_inicial, r->n_blocos, r->modo);
			if(s != NULL)
				remover (r->bloco_inicial, r->n_blocos, r->modo);			
		}
		if(r->modo == 'r'){		
			int inicial = r->bloco_inicial;
			int n_blocos = r->n_blocos;
			remover (r->bloco_inicial, r->n_blocos, 'r');
			manipulador_requisicoes(inicial, n_blocos, 'r');	
		}
	}
}

int main() {
	int bloco_inicial = 0;
	int numero_blocos;
	char modo;

	while(bloco_inicial >= 0){
		scanf("%d", &bloco_inicial);
		
		if(bloco_inicial >= 0){
			scanf("%d %c", &numero_blocos, &modo);
			if(numero_blocos > 0 && numero_blocos <= 64){
				
				if(modo == 'w' || modo == 'r')
					manipulador_requisicoes(bloco_inicial, numero_blocos, modo);
				else
					printf("Modo de requisição invalido\n");
			}
			else
				printf("Quantidade de blocos deve ser entre 0 e 64 por requisição\n");
		}	
	}
	requisicoes *p = head_req;
	printf("Fila:\n");
	while (p != NULL){
		printf("%d %d %c\n", p->bloco_inicial, p->n_blocos, p->modo);
		p = p->prox;
	}
	return 0;
}