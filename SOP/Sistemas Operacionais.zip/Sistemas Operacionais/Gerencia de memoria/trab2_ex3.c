#include <stdio.h>
#include <stdlib.h>

typedef struct node{
	long int page_address; 
	struct node *prox; 
} node_address;

int npf;
int missing_page_fifo = 0;
int missing_page_mru = 0;

node_address *head_fifo = NULL;
node_address *current_fifo = NULL;

node_address *head_mru = NULL;
node_address *current_mru = NULL;

//cria lista para o metodo fifo
node_address * create_list_fifo(long int address){
	node_address * p = (node_address*)malloc(sizeof(node_address));
	if(p == NULL){
		printf("\nFalha ao alocar memoria\n");
		return NULL;
	}
	p->page_address = address; // atribui o valor passado
	p->prox = NULL; // o próximo é NULL
	head_fifo = current_fifo = p;
	return p;
}

node_address * create_list_mru(long int address){
	node_address * p = (node_address*)malloc(sizeof(node_address));
	if(p == NULL){
		printf("\nFalha ao alocar memoria\n");
		return NULL;
	}
	p->page_address = address; // atribui o valor passado
	p->prox = NULL; // o próximo é NULL
	head_mru = current_mru = p;
	return p;
}

// função que adiciona um elemento ao final da lista
node_address* add_list_fifo(long int v){
	if(head_fifo == NULL){
		return create_list_fifo(v);
	}
	node_address * p = (node_address*)malloc(sizeof(node_address));
	if(p == NULL){
		printf("\nFalha ao alocar memoria\n");
		return NULL;
	}
	p->page_address = v;
	p->prox = NULL; 
	current_fifo->prox = p;
	current_fifo = p;
	return p;
}

node_address* add_list_mru(long int v){
	if(head_mru == NULL){	
		return create_list_mru(v);
	}
	node_address * p = (node_address*)malloc(sizeof(node_address));
	p->page_address = v;
	p->prox = NULL; 
	current_mru->prox = p;
	current_mru = p;
	return p;
}
//verifica se a lista está vazia
int lista_vazia_fifo(){
	// se cabeca for NULL, então a lista está vazia
	if(head_fifo == NULL)
		return 1;
	return 0;
}

int lista_vazia_mru(){
	// se cabeca for NULL, então a lista está vazia
	if(head_mru == NULL)
		return 1;
	return 0;
}
// função que retorna o tamanho da lista
int tamanho_lista_fifo(){
	if(lista_vazia_fifo())
		return 0;
	node_address *aux = head_fifo;
	int tam = 0;
	while(aux != NULL){
		tam++;
		aux = aux->prox;
	}
	return tam;
}

int tamanho_lista_mru(){
	if(lista_vazia_mru())
		return 0;
	node_address *aux = head_mru;
	int tam = 0;
	while(aux != NULL){
		tam++;
		aux = aux->prox;
	}
	return tam;
}
//remove cabeça da lista 
void remove_head_fifo(){
	node_address *aux = head_fifo;
	head_fifo = head_fifo->prox;
	free(aux);
}

void remove_head_mru(){
	node_address *aux = head_mru;
	head_mru = head_mru->prox;
	free(aux);
}

 void fifo(long int page){
	int found = 0;
	node_address *aux = head_fifo;
	while(aux != NULL){
		if(aux->page_address == page){
			found = 1;
			break;
		}
		aux = aux->prox;
	}
	if(found == 0){
		missing_page_fifo++;
		if(tamanho_lista_fifo() == npf)
			remove_head_fifo();
		add_list_fifo (page);
	}
}

node_address * buscar_elemento(long int v, node_address **ant){
	// se a lista estiver vazia, então não possui elementos
	if(lista_vazia_mru() == 1)
		return NULL;

	// variável "p" para percorrer a lista
	node_address *p = head_mru;
	// variável "aux_ant" para guardar o anterior
	node_address *aux_ant = NULL;
	// flag "achou" que indica se achou o elemento
	int achou = 0;

	// percorre a lista
	while(p != NULL){
		// se achou, então retorna 1
		if(p->page_address == v){
			achou = 1;
			break;
		}
		// atualiza o "aux_ant"
		aux_ant = p;
		// aponta para o próximo
		p = p->prox;
	}
	// verifica se achou
	if(achou == 1){
		// se "ant" for diferente de NULL
		if(ant)
			*ant = aux_ant; // guarda "aux_ant"
		return p;
	}
	// se chegou aqui, então não achou
	return NULL;
}

void remover_mru(long int v){
	node_address *ant = NULL;

	node_address * elem = buscar_elemento(v, &ant);

	if(elem == NULL)
		return ;

	// se o anterior for diferente de NULL, então
	// faz o próximo do anterior apontar para o próximo
	// do elemento que será removido
	if(ant != NULL)
		ant->prox = elem->prox;

	// se o elemento a ser removido é igual ao corrente, ou seja,
	// é o último elemento, então faz o corrente apontar para o anterior
	if(elem == current_mru)
		current_mru = ant;

	// se o elemento a ser removido é igual a cabeca, ou seja,
	// é o primeiro elemento, então faz a cabeca apontar para o próximo
	// do elemento a ser removido
	if(elem == head_mru)
		head_mru = elem->prox;

	// por último, dá um free no elemento a ser removido "elem" e coloca para NULL
	free(elem);
	elem = NULL;
}

void mru(long int page){
	int found = 0;
	node_address *aux = head_mru;

	while(aux != NULL){
		if(aux->page_address == page){
			remover_mru(page);
			add_list_mru (page);
			found = 1;
			break;
		}
		aux = aux->prox;
	}

	if(found == 0){
		missing_page_mru++;
		if(tamanho_lista_mru() == npf)	
			remove_head_mru(page);
		add_list_mru (page);
	}
}

int main(int argc, char * argv[]) {
	
	if(argv[1] == NULL){
		printf("Numero de paginas fisicas não encontrado\n");
		return 0;
	}

	npf = atoi(argv[1]);

	if(npf < 1 || npf > npf*10)
		return 0;

	long int page = 0;
	
	while(page != -1){
		scanf("%ld", &page);
		if(page < -1 || page > npf*10)
			printf("Endereço invalido");
		
		else
			if(page != -1){
				fifo(page);
				mru(page);
			}
	}
	
	printf("\nFIFO:\t%d falta(s) de pagina(s)\n", missing_page_fifo);
	printf("MRU:\t%d falta(s) de pagina(s)\n", missing_page_mru);
	return 0;
}