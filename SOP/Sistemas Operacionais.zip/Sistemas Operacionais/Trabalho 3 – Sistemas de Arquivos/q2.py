import statistics


arquivo = open('lista-arqs', "r")
n_linhas=0
dados_maior= ['', 0]
zeros = 0
tamanho_total_arquivos = 0
menor_que_a_media = 0
desperdicio = 0
lista_valores = []
for linha in arquivo:
    #conta as linhas 
    n_linhas +=1

    dados_linha = linha.split(' ')
    dados_linha[1] = dados_linha[1].replace('\n', '')
    lista_valores.append(int(dados_linha[1]))
    tamanho_total_arquivos += int(dados_linha[1])
    #verifica o tamanho do maior arquivo
    if int(dados_linha[1]) > int(dados_maior[1]):
        dados_maior = dados_linha

    #conta arquivos com tamanho igual a zero
    if int(dados_linha[1]) == 0:
        zeros +=1

    #conta desperdicio de espaço por fragmentação interna. IO Block: 4096
    resto = int(dados_linha[1])%4096
    desperdicio += 4096-resto

#media do tamanho dos arquivos    
media_tamanho= tamanho_total_arquivos/n_linhas

#mediana
lista_valores.sort()
mediana = statistics.median(lista_valores)

#tamanho do bloco
tamanho_do_bloco = 0
tamanhos_de_bloco_possiveis = [512,1024,2048,4096,8192]
for i in tamanhos_de_bloco_possiveis:
    if mediana < i:
        tamanho_do_bloco = i
        break

#32 bits = 4 Bytes
diretos = tamanho_do_bloco*12
simples = (tamanho_do_bloco/4)*tamanho_do_bloco
duplo = (tamanho_do_bloco/4)*(tamanho_do_bloco/4)*tamanho_do_bloco
triplo = (tamanho_do_bloco/4)*(tamanho_do_bloco/4)*(tamanho_do_bloco/4)*tamanho_do_bloco

arquivo.seek(0)

qtd_arquivos_um_bloco = 0
qtd_diretos = qtd_simples = qtd_duplo = qtd_triplo = 0
for linha in arquivo:
    dados_linha = linha.split(' ')
    #verifica quantos arquivos tem tamanho menor que a media
    if int(dados_linha[1]) < media_tamanho:
        menor_que_a_media += 1
    #verifica quantos arquivos cabem em blocos de 4KB
    if int(dados_linha[1]) <= tamanho_do_bloco:
       qtd_arquivos_um_bloco += 1
    #verifica quantos arquivos cabem em ponteiros diretos
    if int(dados_linha[1]) <= diretos:
       qtd_diretos += 1
    #verifica quantos arquivos que precisam de indireçao simples
    elif int(dados_linha[1]) <= simples:
       qtd_simples += 1
    #verifica quantos arquivos que precisam de indireçao dupla
    elif int(dados_linha[1]) <= duplo:
       qtd_duplo += 1
    #verifica quantos arquivos que precisam de indireçao tripla
    elif int(dados_linha[1]) <= triplo:
       qtd_triplo += 1


arquivo.close()


print ("a-\tO arquivo possui",  n_linhas,  "linhas")
print ("b-\tO maior tamanho de arquivo encontrado é", dados_maior[1], "B e corresponde ao arquivo", dados_maior[0]) 
print ("c-\tForam encontrados", zeros, "arquivos com tamanho igual a 0, correspondendo a {:.5f}% dos arquivos".format(zeros*100/(n_linhas)))
print ("d-\tA media de tamanho dos arquivos é {:.4f}".format(media_tamanho),"B.\n\tHá",menor_que_a_media,"arquivos possuem tamanho menor que a media, correspondendo a {:.5f}% dos arquivos".format(menor_que_a_media*100/n_linhas))
print ("e-\tA mediana é", mediana)
print ("f-\tAdotando blocos com tamanho de",int(tamanho_do_bloco/1024),"KB,",qtd_arquivos_um_bloco, "arquivos ocuparão apenas um bloco, correspondendo a {:.5f}% dos arquivos.".format(qtd_arquivos_um_bloco*100/n_linhas))
print ("g-\tPonteiros diretos(até",int(diretos/1024),"KB): {:.5f}%".format(qtd_diretos*100/n_linhas),
        "\n\tIndirecao simples(até",int(simples/1024/1024),"MB): {:.5f}%".format(qtd_simples*100/n_linhas),
        "\n\tIndirecao dupla(até",int(duplo/1024/1024/1024),"GB): {:.5f}%".format(qtd_duplo*100/n_linhas),
        "\n\tIndirecao tripla(até",int(triplo/1024/1024/1024/1024),"TB): {:.5f}%".format(qtd_triplo*100/n_linhas))
print ("h-\tIO Block: 4096. Total desperdiçado:",desperdicio,"B ({:.2f}".format(desperdicio/1024/1024),"MB),\n\tcorrespondendo a {:.5f}% do total de espaço ocupado pelos arquivos".format(desperdicio*100/tamanho_total_arquivos))
