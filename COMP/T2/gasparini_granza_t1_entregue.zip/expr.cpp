#include "bib.hpp"
#include "syntax.tab.hpp"
/* ********************************** MAIN *****************************/
extern int yyparse(void);
extern string nomeArquivo;
int main(int argc, char *argv[]){

    nomeArquivo = "Teste";
    yyparse();
    // show_symTable();
    return 0;
}